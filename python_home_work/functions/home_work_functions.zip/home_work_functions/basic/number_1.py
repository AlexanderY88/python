# function prints my name
def print_your_name():
    name = "Alex"
    print("My name is " + str(name))


print_your_name()