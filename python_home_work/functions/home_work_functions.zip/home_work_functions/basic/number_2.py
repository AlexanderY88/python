# function receiving string "name" and print it


name = input("Enter your name ")


def print_your_name(my_name):
    print("Hello " + str(my_name))


print_your_name(name)

