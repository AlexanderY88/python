# exercise 4

age = int(input("Enter your age "))
print("Your age is: " + str(age))

#exercise 5
num = int(input("Enter some number: "))
if num % 2 == 0:
    print("The number is even")
else:
    print("The number is odd")
