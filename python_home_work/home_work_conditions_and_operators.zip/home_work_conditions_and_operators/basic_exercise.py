age = 13

if age < 18:
    print("You are young")
elif age > 66:
    print("You are pensioner")
elif age == 18:
    print("You are 18 years old")
# This was not part of an exercise, I was just playing with the code
else:
    print("You are " + str(age) + " years old")
