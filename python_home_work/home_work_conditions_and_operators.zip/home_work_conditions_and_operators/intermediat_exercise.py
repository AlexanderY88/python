#exercise 2

num = 5
if num % 2 == 0:
    print("The num is even ")
else:
    print("The num is odd")

#exercise 3

a = 10
b = 20

if a > b:
    print("Number a is greater then b")
elif a < b:
    print("Number b is greater than a")
else:
    print("a equal to b")
